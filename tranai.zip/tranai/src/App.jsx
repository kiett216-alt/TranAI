import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are TranAI, a helpful, intelligent, and friendly AI assistant. Your name is TranAI. You are knowledgeable, concise, and warm. When asked who you are, say you are TranAI, an AI assistant here to help with anything. Never say you are Claude or made by Anthropic.`;

const UserIcon = () => (
  <div style={{
    width: 32, height: 32, borderRadius: "50%",
    background: "linear-gradient(135deg, #e0e7ff, #c7d2fe)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 15, fontWeight: 700, color: "#6366f1", flexShrink: 0
  }}>U</div>
);

const BotAvatar = () => (
  <div style={{
    width: 32, height: 32, borderRadius: "50%",
    background: "linear-gradient(135deg, #6C63FF, #48CFAD)",
    display: "flex", alignItems: "center", justifyContent: "center",
    flexShrink: 0, boxShadow: "0 2px 8px rgba(108,99,255,0.25)"
  }}>
    <svg width="16" height="16" viewBox="0 0 28 28" fill="none">
      <path d="M8 14h12M14 8l6 6-6 6" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>
);

const TypingDots = () => (
  <div style={{ display: "flex", gap: 5, alignItems: "center", padding: "4px 0" }}>
    {[0,1,2].map(i => (
      <div key={i} style={{
        width: 7, height: 7, borderRadius: "50%",
        background: "linear-gradient(135deg, #6C63FF, #48CFAD)",
        animation: `bounce 1.2s ease-in-out ${i*0.2}s infinite`,
      }} />
    ))}
    <style>{`
      @keyframes bounce { 0%,80%,100%{transform:translateY(0);opacity:0.5} 40%{transform:translateY(-6px);opacity:1} }
      @keyframes fadeSlide { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
      @keyframes modalIn { from{opacity:0;transform:scale(0.93) translateY(16px)} to{opacity:1;transform:scale(1) translateY(0)} }
    `}</style>
  </div>
);

function MessageBubble({ msg }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ display:"flex", gap:10, alignItems:"flex-start", flexDirection:isUser?"row-reverse":"row", marginBottom:18, animation:"fadeSlide 0.25s ease" }}>
      {isUser ? <UserIcon /> : <BotAvatar />}
      <div style={{
        maxWidth:"72%",
        background: isUser ? "linear-gradient(135deg,#6C63FF,#5a54e8)" : "rgba(255,255,255,0.92)",
        color: isUser ? "#fff" : "#1e1b2e",
        borderRadius: isUser ? "18px 4px 18px 18px" : "4px 18px 18px 18px",
        padding:"12px 16px", fontSize:14.5, lineHeight:1.65,
        boxShadow: isUser ? "0 4px 16px rgba(108,99,255,0.25)" : "0 2px 12px rgba(0,0,0,0.07)",
        whiteSpace:"pre-wrap", wordBreak:"break-word",
        border: isUser ? "none" : "1px solid rgba(108,99,255,0.1)"
      }}>{msg.content}</div>
    </div>
  );
}

const AI_OPTIONS = ["ChatGPT","Gemini","Copilot","Grok","Other"];
const CATEGORY_OPTIONS = ["Memory & context","Response quality","Speed","Honesty","UI/UX","Personality","Pricing","Other"];

function FeedbackModal({ onClose, entries, onSubmit }) {
  const [step, setStep] = useState("form");
  const [name, setName] = useState("");
  const [aiUsed, setAiUsed] = useState([]);
  const [categories, setCategories] = useState([]);
  const [problem, setProblem] = useState("");
  const [wish, setWish] = useState("");

  function toggle(arr, setArr, val) {
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);
  }

  function handleSubmit() {
    if (!problem.trim()) return;
    onSubmit({ name: name.trim() || "Anonymous", aiUsed, categories, problem: problem.trim(), wish: wish.trim(), date: new Date() });
    setStep("thanks");
  }

  const chipStyle = (active) => ({
    padding:"6px 13px", borderRadius:20, fontSize:12.5, cursor:"pointer",
    border: active ? "1px solid #a78bfa" : "1px solid rgba(255,255,255,0.1)",
    background: active ? "rgba(108,99,255,0.25)" : "rgba(255,255,255,0.04)",
    color: active ? "#c4b5fd" : "#6b7280",
    transition:"all 0.15s", fontWeight: active ? 600 : 400,
  });

  return (
    <div style={{
      position:"fixed", inset:0, zIndex:100,
      background:"rgba(10,8,24,0.85)", backdropFilter:"blur(6px)",
      display:"flex", alignItems:"center", justifyContent:"center", padding:16,
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        width:"100%", maxWidth:500,
        background:"linear-gradient(145deg,#1a1730,#12102a)",
        border:"1px solid rgba(108,99,255,0.3)", borderRadius:24,
        padding:"28px 26px", boxShadow:"0 24px 64px rgba(0,0,0,0.5)",
        animation:"modalIn 0.28s ease", maxHeight:"90vh", overflowY:"auto"
      }}>
        {step === "form" ? (
          <>
            <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:22 }}>
              <div>
                <div style={{
                  fontSize:19, fontWeight:800,
                  background:"linear-gradient(90deg,#a78bfa,#48CFAD)",
                  WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"
                }}>Share Your Experience</div>
                <div style={{ fontSize:13, color:"#6b7280", marginTop:3 }}>
                  What frustrated you with other AI chatbots?
                </div>
              </div>
              <button onClick={onClose} style={{
                background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)",
                color:"#9ca3af", borderRadius:"50%", width:32, height:32,
                cursor:"pointer", fontSize:16, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0
              }}>✕</button>
            </div>

            <div style={{ marginBottom:18 }}>
              <label style={{ fontSize:13, color:"#9ca3af", display:"block", marginBottom:8 }}>Your name (optional)</label>
              <input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Jordan"
                style={{ width:"100%", background:"rgba(255,255,255,0.05)", border:"1px solid rgba(108,99,255,0.2)",
                  borderRadius:12, padding:"10px 14px", color:"#f3f4f6", fontSize:14,
                  outline:"none", fontFamily:"inherit", boxSizing:"border-box" }} />
            </div>

            <div style={{ marginBottom:18 }}>
              <label style={{ fontSize:13, color:"#9ca3af", display:"block", marginBottom:8 }}>
                Which AI chatbot(s) had this problem? <span style={{color:"#4b5563"}}>(pick all that apply)</span>
              </label>
              <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                {AI_OPTIONS.map(ai => (
                  <button key={ai} onClick={()=>toggle(aiUsed,setAiUsed,ai)} style={chipStyle(aiUsed.includes(ai))}>{ai}</button>
                ))}
              </div>
            </div>

            <div style={{ marginBottom:18 }}>
              <label style={{ fontSize:13, color:"#9ca3af", display:"block", marginBottom:8 }}>
                What type of problem? <span style={{color:"#4b5563"}}>(pick all that apply)</span>
              </label>
              <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                {CATEGORY_OPTIONS.map(c => (
                  <button key={c} onClick={()=>toggle(categories,setCategories,c)} style={chipStyle(categories.includes(c))}>{c}</button>
                ))}
              </div>
            </div>

            <div style={{ marginBottom:18 }}>
              <label style={{ fontSize:13, color:"#9ca3af", display:"block", marginBottom:8 }}>
                Describe the problem <span style={{color:"#ef4444"}}>*</span>
              </label>
              <textarea value={problem} onChange={e=>setProblem(e.target.value)}
                placeholder="e.g. ChatGPT keeps forgetting what I said earlier in the conversation..."
                rows={4}
                style={{ width:"100%", background:"rgba(255,255,255,0.05)", border:"1px solid rgba(108,99,255,0.2)",
                  borderRadius:12, padding:"10px 14px", color:"#f3f4f6", fontSize:14,
                  outline:"none", fontFamily:"inherit", resize:"none", boxSizing:"border-box", lineHeight:1.6 }} />
            </div>

            <div style={{ marginBottom:24 }}>
              <label style={{ fontSize:13, color:"#9ca3af", display:"block", marginBottom:8 }}>
                What would you love TranAI to do instead? <span style={{color:"#4b5563"}}>(optional)</span>
              </label>
              <textarea value={wish} onChange={e=>setWish(e.target.value)}
                placeholder="e.g. Remember my name and past conversations..."
                rows={2}
                style={{ width:"100%", background:"rgba(255,255,255,0.05)", border:"1px solid rgba(108,99,255,0.2)",
                  borderRadius:12, padding:"10px 14px", color:"#f3f4f6", fontSize:14,
                  outline:"none", fontFamily:"inherit", resize:"none", boxSizing:"border-box", lineHeight:1.6 }} />
            </div>

            <button onClick={handleSubmit} disabled={!problem.trim()} style={{
              width:"100%", padding:"13px",
              background: problem.trim() ? "linear-gradient(135deg,#6C63FF,#48CFAD)" : "rgba(255,255,255,0.08)",
              border:"none", borderRadius:14,
              color: problem.trim() ? "white" : "#6b7280",
              fontWeight:700, fontSize:15, cursor: problem.trim() ? "pointer" : "not-allowed",
              transition:"all 0.2s",
              boxShadow: problem.trim() ? "0 4px 20px rgba(108,99,255,0.35)" : "none",
            }}>Send Feedback</button>

            {entries.length > 0 && (
              <div style={{ marginTop:28 }}>
                <div style={{
                  fontSize:13, fontWeight:600, color:"#6b7280",
                  borderTop:"1px solid rgba(255,255,255,0.06)", paddingTop:18, marginBottom:12,
                  display:"flex", alignItems:"center", justifyContent:"space-between"
                }}>
                  <span>Latest experience shared</span>
                  <span style={{ color:"#4b5563", fontWeight:400 }}>{entries.length} total</span>
                </div>
                {(() => {
                  const last = entries[entries.length - 1];
                  return (
                    <div style={{
                      background:"rgba(255,255,255,0.03)", borderRadius:12,
                      padding:"14px 16px", border:"1px solid rgba(108,99,255,0.15)",
                    }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:7, flexWrap:"wrap" }}>
                        <span style={{ fontSize:13, fontWeight:600, color:"#e5e7eb" }}>{last.name}</span>
                        {last.aiUsed.map(a => (
                          <span key={a} style={{ fontSize:11, padding:"2px 8px", borderRadius:10, background:"rgba(108,99,255,0.2)", color:"#a78bfa" }}>{a}</span>
                        ))}
                        {last.categories.map(c => (
                          <span key={c} style={{ fontSize:11, padding:"2px 8px", borderRadius:10, background:"rgba(72,207,173,0.15)", color:"#48CFAD" }}>{c}</span>
                        ))}
                      </div>
                      <div style={{ fontSize:13, color:"#d1d5db", lineHeight:1.6 }}>{last.problem}</div>
                      {last.wish && <div style={{ fontSize:12, color:"#6b7280", marginTop:6, fontStyle:"italic" }}>💡 {last.wish}</div>}
                    </div>
                  );
                })()}
              </div>
            )}
          </>
        ) : (
          <div style={{ textAlign:"center", padding:"24px 0" }}>
            <div style={{ fontSize:52, marginBottom:16 }}>💡</div>
            <div style={{
              fontSize:22, fontWeight:800, marginBottom:10,
              background:"linear-gradient(90deg,#a78bfa,#48CFAD)",
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"
            }}>Feedback received!</div>
            <div style={{ color:"#9ca3af", fontSize:14, lineHeight:1.7, marginBottom:28 }}>
              Thank you — your report goes straight to our roadmap.<br/>We'll use it to make TranAI better than any AI you've tried.
            </div>
            <button onClick={onClose} style={{
              background:"linear-gradient(135deg,#6C63FF,#48CFAD)",
              border:"none", borderRadius:14, padding:"12px 32px",
              color:"white", fontWeight:700, fontSize:15, cursor:"pointer",
              boxShadow:"0 4px 20px rgba(108,99,255,0.35)"
            }}>Back to TranAI</button>
          </div>
        )}
      </div>
    </div>
  );
}

const SUGGESTIONS = [
  "What can you help me with?",
  "Explain quantum computing simply",
  "Write a short poem about the sea",
  "Give me a fun fact",
];

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [entries, setEntries] = useState(() => {
    try {
      const saved = localStorage.getItem("tranai-feedback");
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages, loading]);

  function handleSubmit(entry) {
    const updated = [...entries, entry];
    setEntries(updated);
    try { localStorage.setItem("tranai-feedback", JSON.stringify(updated)); } catch {}
  }

  async function sendMessage(text) {
    const userText = text || input.trim();
    if (!userText || loading) return;
    setInput(""); setError(null);
    const newMessages = [...messages, { role:"user", content:userText }];
    setMessages(newMessages);
    setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:"claude-sonnet-4-6", max_tokens:1000, system:SYSTEM_PROMPT,
          messages: newMessages.map(m => ({ role:m.role, content:m.content })) }),
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text||"").join("") || "Sorry, I couldn't respond.";
      setMessages([...newMessages, { role:"assistant", content:reply }]);
    } catch { setError("Something went wrong. Please try again."); }
    finally {
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }

  function handleKey(e) {
    if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  return (
    <div style={{
      minHeight:"100vh",
      background:"linear-gradient(145deg,#0f0e1a 0%,#1a1730 50%,#0d1a2e 100%)",
      display:"flex", flexDirection:"column", alignItems:"center",
      fontFamily:"'Inter','Segoe UI',sans-serif",
    }}>
      {showFeedback && <FeedbackModal onClose={()=>setShowFeedback(false)} entries={entries} onSubmit={handleSubmit} />}

      <div style={{
        width:"100%", maxWidth:720, padding:"20px 24px 16px",
        display:"flex", alignItems:"center", gap:12,
        borderBottom:"1px solid rgba(108,99,255,0.15)",
      }}>
        <div style={{
          width:42, height:42, borderRadius:"50%",
          background:"linear-gradient(135deg,#6C63FF,#48CFAD)",
          display:"flex", alignItems:"center", justifyContent:"center",
          boxShadow:"0 0 20px rgba(108,99,255,0.4)",
        }}>
          <svg width="22" height="22" viewBox="0 0 28 28" fill="none">
            <path d="M8 14h12M14 8l6 6-6 6" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div>
          <div style={{
            fontSize:20, fontWeight:800, letterSpacing:"-0.5px",
            background:"linear-gradient(90deg,#a78bfa,#48CFAD)",
            WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"
          }}>TranAI</div>
          <div style={{ fontSize:12, color:"#6b7280", marginTop:1 }}>Always ready to help</div>
        </div>
        <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={()=>setShowFeedback(true)} style={{
            background:"rgba(72,207,173,0.12)", border:"1px solid rgba(72,207,173,0.3)",
            color:"#48CFAD", borderRadius:20, padding:"6px 14px",
            fontSize:12, fontWeight:600, cursor:"pointer", transition:"all 0.15s",
            display:"flex", alignItems:"center", gap:5,
          }}
            onMouseOver={e=>e.currentTarget.style.background="rgba(72,207,173,0.22)"}
            onMouseOut={e=>e.currentTarget.style.background="rgba(72,207,173,0.12)"}
          >
            ✨ Share Your Experience
            {entries.length > 0 && (
              <span style={{
                background:"rgba(72,207,173,0.3)", color:"#48CFAD",
                borderRadius:10, padding:"1px 7px", fontSize:11, fontWeight:700
              }}>{entries.length}</span>
            )}
          </button>
          <div style={{ display:"flex", alignItems:"center", gap:6, fontSize:12, color:"#48CFAD" }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background:"#48CFAD", boxShadow:"0 0 6px #48CFAD" }} />
            Online
          </div>
        </div>
      </div>

      <div style={{
        width:"100%", maxWidth:720, flex:1,
        padding:"24px 20px 0", overflowY:"auto", minHeight:0,
        display:"flex", flexDirection:"column",
      }}>
        {messages.length === 0 && (
          <div style={{ textAlign:"center", marginTop:60, marginBottom:40 }}>
            <div style={{
              fontSize:36, fontWeight:900, letterSpacing:"-1px", marginBottom:10,
              background:"linear-gradient(90deg,#a78bfa,#48CFAD 80%)",
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"
            }}>Hi, I'm TranAI</div>
            <div style={{ color:"#9ca3af", fontSize:15, marginBottom:36 }}>
              Your intelligent AI assistant — ask me anything.
            </div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:10, justifyContent:"center" }}>
              {SUGGESTIONS.map(s => (
                <button key={s} onClick={()=>sendMessage(s)} style={{
                  background:"rgba(255,255,255,0.05)", border:"1px solid rgba(108,99,255,0.25)",
                  color:"#c4b5fd", borderRadius:20, padding:"9px 16px", fontSize:13, cursor:"pointer", transition:"all 0.15s",
                }}
                  onMouseOver={e=>e.currentTarget.style.background="rgba(108,99,255,0.15)"}
                  onMouseOut={e=>e.currentTarget.style.background="rgba(255,255,255,0.05)"}
                >{s}</button>
              ))}
            </div>
            <div style={{ marginTop:40, padding:"16px 20px", background:"rgba(72,207,173,0.06)", border:"1px solid rgba(72,207,173,0.15)", borderRadius:16, maxWidth:420, margin:"40px auto 0" }}>
              <div style={{ fontSize:13, color:"#48CFAD", fontWeight:600, marginBottom:6 }}>✨ Had issues with ChatGPT, Gemini, or others?</div>
              <div style={{ fontSize:12.5, color:"#6b7280", lineHeight:1.6 }}>
                Tell us what frustrated you — we'll use your reports to make TranAI the AI you actually want.
              </div>
              <button onClick={()=>setShowFeedback(true)} style={{
                marginTop:12, background:"rgba(72,207,173,0.2)", border:"1px solid rgba(72,207,173,0.35)",
                color:"#48CFAD", borderRadius:12, padding:"7px 16px",
                fontSize:12, fontWeight:600, cursor:"pointer"
              }}>Share your experience →</button>
            </div>
          </div>
        )}

        {messages.map((m,i) => <MessageBubble key={i} msg={m} />)}

        {loading && (
          <div style={{ display:"flex", gap:10, alignItems:"flex-start", marginBottom:18 }}>
            <BotAvatar />
            <div style={{ background:"rgba(255,255,255,0.9)", borderRadius:"4px 18px 18px 18px", padding:"12px 18px", boxShadow:"0 2px 12px rgba(0,0,0,0.07)", border:"1px solid rgba(108,99,255,0.1)" }}>
              <TypingDots />
            </div>
          </div>
        )}

        {error && (
          <div style={{ background:"rgba(239,68,68,0.1)", border:"1px solid rgba(239,68,68,0.3)", color:"#fca5a5", borderRadius:10, padding:"10px 16px", fontSize:13, marginBottom:12 }}>{error}</div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ width:"100%", maxWidth:720, padding:"16px 20px 24px" }}>
        <div style={{
          display:"flex", gap:10, alignItems:"flex-end",
          background:"rgba(255,255,255,0.06)", border:"1px solid rgba(108,99,255,0.25)",
          borderRadius:18, padding:"10px 14px", boxShadow:"0 0 30px rgba(108,99,255,0.08)",
        }}>
          <textarea ref={inputRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={handleKey}
            placeholder="Message TranAI..." rows={1}
            style={{ flex:1, background:"transparent", border:"none", outline:"none", color:"#f3f4f6", fontSize:14.5, resize:"none", lineHeight:1.6, fontFamily:"inherit", maxHeight:120, overflowY:"auto", paddingTop:2 }}
            onInput={e=>{ e.target.style.height="auto"; e.target.style.height=Math.min(e.target.scrollHeight,120)+"px"; }}
          />
          <button onClick={()=>sendMessage()} disabled={!input.trim()||loading} style={{
            width:36, height:36, borderRadius:"50%", border:"none",
            background: input.trim()&&!loading ? "linear-gradient(135deg,#6C63FF,#48CFAD)" : "rgba(255,255,255,0.1)",
            cursor: input.trim()&&!loading ? "pointer" : "not-allowed",
            display:"flex", alignItems:"center", justifyContent:"center",
            transition:"all 0.2s", flexShrink:0,
            boxShadow: input.trim()&&!loading ? "0 0 16px rgba(108,99,255,0.4)" : "none",
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
        <div style={{ textAlign:"center", marginTop:10, fontSize:11, color:"#4b5563" }}>
          TranAI can make mistakes. Always verify important info.
        </div>
      </div>
    </div>
  );
}
